<?php

  $conn = mysqli_connect('localhost','root','','challange') or die($conn);

?>
