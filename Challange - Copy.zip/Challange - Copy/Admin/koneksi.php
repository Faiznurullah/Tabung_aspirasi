<?php

$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "challange";
$connect    = mysqli_connect($host, $user, $password, $database)


?>
